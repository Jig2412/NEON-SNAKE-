export function PauseOverlay() {
  return (
    <div className="absolute inset-0 bg-[#0a0e14] bg-opacity-85 flex flex-col items-center justify-center z-10">
      <h2 className="font-display text-7xl text-white mb-6 tracking-wider drop-shadow-[4px_4px_0_#000]">
        PAUSED
      </h2>
      <p className="font-body text-white text-xl">Press SPACEBAR to resume</p>
    </div>
  );
}
