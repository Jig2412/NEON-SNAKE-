import { GameMode } from './types';
import { useState } from 'react';

interface StartScreenProps {
  onStart: (mode: GameMode) => void;
}

export function StartScreen({ onStart }: StartScreenProps) {
  const [selectedMode, setSelectedMode] = useState<GameMode>('CLASSIC');

  const modes: { value: GameMode; label: string; description: string }[] = [
    { value: 'CLASSIC', label: 'CLASSIC', description: 'Traditional snake game' },
    { value: 'SPEED', label: 'SPEED MODE', description: 'Speed increases with each food' },
    { value: 'ENDLESS', label: 'ENDLESS', description: 'No walls + bombs spawn every 5s' },
  ];

  return (
    <div className="absolute inset-0 bg-[#0a0e14] bg-opacity-95 flex flex-col items-center justify-center z-10 noise-texture">
      <h1 className="font-display text-8xl md:text-9xl text-white mb-8 tracking-wider drop-shadow-[6px_6px_0_#000]">
        SNAKE
      </h1>

      <div className="font-body text-white text-lg mb-8 space-y-2 text-center">
        <p className="font-bold text-[#39ff14]">USE ARROW KEYS OR WASD TO MOVE</p>
        <p className="text-base">Press SPACEBAR to pause</p>
        <p className="text-sm text-gray-400">Eat food • Avoid walls • Don't bite yourself</p>
      </div>

      {/* Mode Selection */}
      <div className="mb-10 space-y-4">
        <h2 className="font-display text-2xl text-white text-center mb-4">SELECT MODE</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {modes.map((mode) => (
            <button
              key={mode.value}
              onClick={() => setSelectedMode(mode.value)}
              className={`font-display text-lg px-6 py-4 border-[4px] border-black brutalist-shadow uppercase transition-all hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[4px_4px_0_0_#000] ${
                selectedMode === mode.value
                  ? 'bg-[#39ff14] text-black shadow-[0_0_20px_rgba(57,255,20,0.4)]'
                  : 'bg-[#1a1f26] text-white'
              }`}
            >
              <div className="font-bold">{mode.label}</div>
              <div className="text-xs font-body normal-case mt-1">{mode.description}</div>
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={() => onStart(selectedMode)}
        className="font-display text-2xl px-12 py-6 bg-[#ff6600] text-white border-[6px] border-black brutalist-shadow uppercase hover:translate-x-[3px] hover:translate-y-[3px] hover:shadow-[3px_3px_0_0_#000] transition-all active:translate-x-[6px] active:translate-y-[6px] active:shadow-none"
      >
        START GAME
      </button>
    </div>
  );
}
