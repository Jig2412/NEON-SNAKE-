import { useState, useEffect, useCallback, useRef } from 'react';
import { GameCanvas } from './GameCanvas';
import { StartScreen } from './StartScreen';
import { PauseOverlay } from './PauseOverlay';
import { GameOverScreen } from './GameOverScreen';
import { MobileDPad } from './MobileDPad';
import {
  Position,
  Direction,
  GameState,
  GameMode,
  GRID_SIZE,
  INITIAL_SPEED,
  SPEED_INCREMENT,
  POINTS_PER_LEVEL,
} from './types';
import {
  getRandomPosition,
  checkCollision,
  checkWallCollision,
  getHighScore,
  saveHighScore,
} from './utils';

const INITIAL_SNAKE: Position[] = [
  { x: 10, y: 10 },
  { x: 10, y: 11 },
  { x: 10, y: 12 },
];

export function SnakeGame() {
  const [gameState, setGameState] = useState<GameState>('START');
  const [gameMode, setGameMode] = useState<GameMode>('CLASSIC');
  const [snake, setSnake] = useState<Position[]>(INITIAL_SNAKE);
  const [direction, setDirection] = useState<Direction>('UP');
  const [nextDirection, setNextDirection] = useState<Direction>('UP');
  const [food, setFood] = useState<Position>(getRandomPosition(INITIAL_SNAKE));
  const [bombs, setBombs] = useState<Position[]>([]);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(getHighScore());
  const [speed, setSpeed] = useState(INITIAL_SPEED);
  const [shake, setShake] = useState(false);
  const [scoreAnimation, setScoreAnimation] = useState(false);

  const gameLoopRef = useRef<number | null>(null);
  const lastMoveTimeRef = useRef<number>(0);
  const bombSpawnTimerRef = useRef<number | null>(null);

  // Handle keyboard input
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Prevent default for arrow keys and spacebar
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === ' ' && gameState !== 'START' && gameState !== 'GAME_OVER') {
        setGameState(prev => prev === 'PLAYING' ? 'PAUSED' : 'PLAYING');
        return;
      }

      if (gameState !== 'PLAYING') return;

      let newDirection: Direction | null = null;

      switch (e.key.toLowerCase()) {
        case 'arrowup':
        case 'w':
          newDirection = 'UP';
          break;
        case 'arrowdown':
        case 's':
          newDirection = 'DOWN';
          break;
        case 'arrowleft':
        case 'a':
          newDirection = 'LEFT';
          break;
        case 'arrowright':
        case 'd':
          newDirection = 'RIGHT';
          break;
      }

      if (newDirection) {
        // Prevent reverse direction
        const opposites: Record<Direction, Direction> = {
          UP: 'DOWN',
          DOWN: 'UP',
          LEFT: 'RIGHT',
          RIGHT: 'LEFT',
        };

        if (opposites[newDirection] !== direction) {
          setNextDirection(newDirection);
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gameState, direction]);

  // Bomb spawning for ENDLESS mode
  useEffect(() => {
    if (gameState === 'PLAYING' && gameMode === 'ENDLESS') {
      bombSpawnTimerRef.current = window.setInterval(() => {
        setBombs(prevBombs => {
          const occupiedPositions = [...snake, food, ...prevBombs];
          const newBomb = getRandomPosition(occupiedPositions);
          return [...prevBombs, newBomb];
        });
      }, 5000); // Spawn every 5 seconds

      return () => {
        if (bombSpawnTimerRef.current) {
          clearInterval(bombSpawnTimerRef.current);
        }
      };
    } else {
      if (bombSpawnTimerRef.current) {
        clearInterval(bombSpawnTimerRef.current);
      }
    }
  }, [gameState, gameMode, snake, food]);

  // Handle mobile D-pad input
  const handleMobileDirectionChange = useCallback((newDirection: Direction) => {
    if (gameState !== 'PLAYING') return;

    // Prevent reverse direction
    const opposites: Record<Direction, Direction> = {
      UP: 'DOWN',
      DOWN: 'UP',
      LEFT: 'RIGHT',
      RIGHT: 'LEFT',
    };

    if (opposites[newDirection] !== direction) {
      setNextDirection(newDirection);
    }
  }, [gameState, direction]);

  // Game loop
  useEffect(() => {
    if (gameState !== 'PLAYING') {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
      return;
    }

    const gameLoop = (timestamp: number) => {
      if (timestamp - lastMoveTimeRef.current >= speed) {
        lastMoveTimeRef.current = timestamp;
        moveSnake();
      }
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoopRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [gameState, snake, direction, nextDirection, speed]);

  const moveSnake = useCallback(() => {
    setDirection(nextDirection);

    const head = snake[0];
    let newHead: Position;

    switch (nextDirection) {
      case 'UP':
        newHead = { x: head.x, y: head.y - 1 };
        break;
      case 'DOWN':
        newHead = { x: head.x, y: head.y + 1 };
        break;
      case 'LEFT':
        newHead = { x: head.x - 1, y: head.y };
        break;
      case 'RIGHT':
        newHead = { x: head.x + 1, y: head.y };
        break;
    }

    // Check wall collision (except in ENDLESS mode)
    if (gameMode !== 'ENDLESS' && checkWallCollision(newHead)) {
      triggerGameOver();
      return;
    }

    // In ENDLESS mode, wrap around walls
    if (gameMode === 'ENDLESS') {
      if (newHead.x < 0) newHead.x = GRID_SIZE - 1;
      if (newHead.x >= GRID_SIZE) newHead.x = 0;
      if (newHead.y < 0) newHead.y = GRID_SIZE - 1;
      if (newHead.y >= GRID_SIZE) newHead.y = 0;
    }

    // Check self collision
    if (checkCollision(newHead, snake)) {
      triggerGameOver();
      return;
    }

    // Check bomb collision
    if (checkCollision(newHead, bombs)) {
      triggerGameOver();
      return;
    }

    const newSnake = [newHead, ...snake];

    // Check food collision
    if (newHead.x === food.x && newHead.y === food.y) {
      // Grow snake (don't remove tail)
      const newScore = score + 1;
      setScore(newScore);
      setScoreAnimation(true);
      setTimeout(() => setScoreAnimation(false), 300);

      // Spawn new food
      setFood(getRandomPosition(newSnake));

      // Increase speed based on game mode
      if (gameMode === 'SPEED') {
        // Speed mode: increase speed with each food
        setSpeed(prev => Math.max(50, prev - SPEED_INCREMENT));
      } else if (gameMode === 'CLASSIC' && newScore % POINTS_PER_LEVEL === 0) {
        // Classic mode: increase speed every POINTS_PER_LEVEL points
        setSpeed(prev => Math.max(50, prev - SPEED_INCREMENT));
      }
      // ENDLESS mode: no speed increase

      setSnake(newSnake);
    } else {
      // Move snake (remove tail)
      newSnake.pop();
      setSnake(newSnake);
    }
  }, [snake, nextDirection, food, score, bombs, gameMode]);

  const triggerGameOver = () => {
    setShake(true);
    setTimeout(() => {
      setShake(false);
      saveHighScore(score);
      setHighScore(Math.max(score, highScore));
      setGameState('GAME_OVER');
    }, 200);
  };

  const startGame = (mode: GameMode) => {
    setGameMode(mode);
    setGameState('PLAYING');
  };

  const restartGame = () => {
    setSnake(INITIAL_SNAKE);
    setDirection('UP');
    setNextDirection('UP');
    setFood(getRandomPosition(INITIAL_SNAKE));
    setBombs([]);
    setScore(0);
    setSpeed(INITIAL_SPEED);
    setShake(false);
    setGameState('START');
    lastMoveTimeRef.current = 0;
    if (bombSpawnTimerRef.current) {
      clearInterval(bombSpawnTimerRef.current);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0e14] noise-texture flex flex-col items-center justify-center p-8 md:p-16">
      {/* Score displays */}
      <div className="w-full max-w-[600px] flex justify-between mb-8">
        <div className="text-left">
          <p className="font-body text-white text-sm mb-1 uppercase tracking-wide">Score</p>
          <p className={`font-mono-bold text-5xl text-[#39ff14] ${scoreAnimation ? 'animate-score-pop' : ''}`}>
            {score}
          </p>
        </div>
        <div className="text-right">
          <p className="font-body text-white text-sm mb-1 uppercase tracking-wide">High Score</p>
          <p className="font-mono-bold text-5xl text-[#ccff00]">
            {highScore}
          </p>
        </div>
      </div>

      {/* Game container */}
      <div className="relative">
        <GameCanvas snake={snake} food={food} bombs={bombs} shake={shake} />
        
        {gameState === 'START' && <StartScreen onStart={startGame} />}
        {gameState === 'PAUSED' && <PauseOverlay />}
        {gameState === 'GAME_OVER' && (
          <GameOverScreen score={score} highScore={highScore} onRestart={restartGame} />
        )}
      </div>

      {/* Mobile D-Pad - positioned below the board */}
      {gameState === 'PLAYING' && (
        <div className="flex justify-center mt-8 md:hidden">
          <MobileDPad onDirectionChange={handleMobileDirectionChange} />
        </div>
      )}

      {/* Speed/Level indicator */}
      {gameState === 'PLAYING' && (
        <div className="mt-8 text-center">
          <p className="font-body text-gray-400 text-sm uppercase tracking-wide">
            {gameMode === 'CLASSIC' && `Level ${Math.floor(score / POINTS_PER_LEVEL) + 1}`}
            {gameMode === 'SPEED' && 'SPEED MODE - Getting Faster!'}
            {gameMode === 'ENDLESS' && `ENDLESS MODE - ${bombs.length} Bombs`}
          </p>
        </div>
      )}
    </div>
  );
}
