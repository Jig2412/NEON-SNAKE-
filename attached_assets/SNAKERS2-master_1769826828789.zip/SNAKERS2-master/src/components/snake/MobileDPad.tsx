import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';

interface MobileDPadProps {
  onDirectionChange: (direction: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => void;
}

export function MobileDPad({ onDirectionChange }: MobileDPadProps) {
  return (
    <div className="flex flex-col items-center gap-2">{/* Up Button */}
      <button
        onMouseDown={() => onDirectionChange('UP')}
        onTouchStart={() => onDirectionChange('UP')}
        className="w-16 h-16 bg-[#ff6600] border-4 border-black shadow-[6px_6px_0px_rgba(0,0,0,1)] hover:shadow-[3px_3px_0px_rgba(0,0,0,1)] hover:translate-y-1 hover:translate-x-1 transition-all active:shadow-[3px_3px_0px_rgba(0,0,0,1)] active:translate-y-1 active:translate-x-1 flex items-center justify-center"
      >
        <ChevronUp size={32} className="text-white font-bold" strokeWidth={4} />
      </button>

      {/* Left, Center (empty), Right */}
      <div className="flex gap-2">
        <button
          onMouseDown={() => onDirectionChange('LEFT')}
          onTouchStart={() => onDirectionChange('LEFT')}
          className="w-16 h-16 bg-[#ff6600] border-4 border-black shadow-[6px_6px_0px_rgba(0,0,0,1)] hover:shadow-[3px_3px_0px_rgba(0,0,0,1)] hover:translate-y-1 hover:translate-x-1 transition-all active:shadow-[3px_3px_0px_rgba(0,0,0,1)] active:translate-y-1 active:translate-x-1 flex items-center justify-center"
        >
          <ChevronLeft size={32} className="text-white font-bold" strokeWidth={4} />
        </button>

        {/* Center - empty space */}
        <div className="w-16 h-16" />

        <button
          onMouseDown={() => onDirectionChange('RIGHT')}
          onTouchStart={() => onDirectionChange('RIGHT')}
          className="w-16 h-16 bg-[#ff6600] border-4 border-black shadow-[6px_6px_0px_rgba(0,0,0,1)] hover:shadow-[3px_3px_0px_rgba(0,0,0,1)] hover:translate-y-1 hover:translate-x-1 transition-all active:shadow-[3px_3px_0px_rgba(0,0,0,1)] active:translate-y-1 active:translate-x-1 flex items-center justify-center"
        >
          <ChevronRight size={32} className="text-white font-bold" strokeWidth={4} />
        </button>
      </div>

      {/* Down Button */}
      <button
        onMouseDown={() => onDirectionChange('DOWN')}
        onTouchStart={() => onDirectionChange('DOWN')}
        className="w-16 h-16 bg-[#ff6600] border-4 border-black shadow-[6px_6px_0px_rgba(0,0,0,1)] hover:shadow-[3px_3px_0px_rgba(0,0,0,1)] hover:translate-y-1 hover:translate-x-1 transition-all active:shadow-[3px_3px_0px_rgba(0,0,0,1)] active:translate-y-1 active:translate-x-1 flex items-center justify-center"
      >
        <ChevronDown size={32} className="text-white font-bold" strokeWidth={4} />
      </button>
    </div>
  );
}
