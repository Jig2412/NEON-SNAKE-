import { useEffect, useRef, useState } from 'react';
import { Position, CELL_SIZE, GRID_SIZE } from './types';

interface GameCanvasProps {
  snake: Position[];
  food: Position;
  bombs: Position[];
  shake: boolean;
}

export function GameCanvas({ snake, food, bombs, shake }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [foodScale, setFoodScale] = useState(1);

  // Animate food pulsing
  useEffect(() => {
    let animationFrame: number;
    let startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = (elapsed % 800) / 800; // 800ms loop
      
      // Scale from 1.0 to 1.2 and back
      const scale = 1 + Math.sin(progress * Math.PI * 2) * 0.1;
      setFoodScale(scale);
      
      animationFrame = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#0a0e14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw subtle grid lines
    ctx.strokeStyle = '#1a1f26';
    ctx.lineWidth = 1;
    for (let i = 0; i <= GRID_SIZE; i++) {
      // Vertical lines
      ctx.beginPath();
      ctx.moveTo(i * CELL_SIZE, 0);
      ctx.lineTo(i * CELL_SIZE, canvas.height);
      ctx.stroke();

      // Horizontal lines
      ctx.beginPath();
      ctx.moveTo(0, i * CELL_SIZE);
      ctx.lineTo(canvas.width, i * CELL_SIZE);
      ctx.stroke();
    }

    // Draw snake body
    snake.forEach((segment, index) => {
      if (index === 0) {
        // Head - brighter yellow-green
        ctx.fillStyle = '#ccff00';
      } else {
        // Body - electric lime green
        ctx.fillStyle = index % 2 === 0 ? '#39ff14' : '#2acc10';
      }

      ctx.fillRect(
        segment.x * CELL_SIZE + 1,
        segment.y * CELL_SIZE + 1,
        CELL_SIZE - 2,
        CELL_SIZE - 2
      );
    });

    // Draw food with glow effect and pulsing animation
    const foodCenterX = food.x * CELL_SIZE + CELL_SIZE / 2;
    const foodCenterY = food.y * CELL_SIZE + CELL_SIZE / 2;
    const foodSize = (CELL_SIZE - 4) * foodScale;

    ctx.save();
    ctx.translate(foodCenterX, foodCenterY);

    // Glow effect
    ctx.shadowBlur = 15 * foodScale;
    ctx.shadowColor = '#ff006e';
    ctx.fillStyle = '#ff006e';
    ctx.fillRect(
      -foodSize / 2,
      -foodSize / 2,
      foodSize,
      foodSize
    );

    ctx.restore();
    // Reset shadow
    ctx.shadowBlur = 0;

    // Draw bombs
    bombs.forEach((bomb) => {
      const bombCenterX = bomb.x * CELL_SIZE + CELL_SIZE / 2;
      const bombCenterY = bomb.y * CELL_SIZE + CELL_SIZE / 2;
      const bombSize = CELL_SIZE - 4;

      ctx.save();
      ctx.translate(bombCenterX, bombCenterY);

      // Bomb body - red with black border
      ctx.fillStyle = '#dc2626'; // red-600
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 2;
      ctx.fillRect(-bombSize / 2, -bombSize / 2, bombSize, bombSize);
      ctx.strokeRect(-bombSize / 2, -bombSize / 2, bombSize, bombSize);

      // Bomb glow
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#dc2626';

      ctx.restore();
    });

    ctx.shadowBlur = 0;
  }, [snake, food, bombs, foodScale]);

  return (
    <canvas
      ref={canvasRef}
      width={400}
      height={400}
      className={`border-[8px] border-black neon-glow-green ${shake ? 'animate-shake' : ''}`}
      style={{ imageRendering: 'pixelated' }}
    />
  );
}
