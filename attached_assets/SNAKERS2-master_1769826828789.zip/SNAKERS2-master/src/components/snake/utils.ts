import { Position, GRID_SIZE } from './types';

export const getRandomPosition = (excludePositions: Position[] = []): Position => {
  let position: Position;
  let isValid = false;

  while (!isValid) {
    position = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE)
    };

    isValid = !excludePositions.some(
      pos => pos.x === position.x && pos.y === position.y
    );
  }

  return position!;
};

export const checkCollision = (position: Position, obstacles: Position[]): boolean => {
  return obstacles.some(obs => obs.x === position.x && obs.y === position.y);
};

export const checkWallCollision = (position: Position): boolean => {
  return (
    position.x < 0 ||
    position.x >= GRID_SIZE ||
    position.y < 0 ||
    position.y >= GRID_SIZE
  );
};

export const getHighScore = (): number => {
  const saved = localStorage.getItem('snake-high-score');
  return saved ? parseInt(saved, 10) : 0;
};

export const saveHighScore = (score: number): void => {
  const currentHigh = getHighScore();
  if (score > currentHigh) {
    localStorage.setItem('snake-high-score', score.toString());
  }
};
