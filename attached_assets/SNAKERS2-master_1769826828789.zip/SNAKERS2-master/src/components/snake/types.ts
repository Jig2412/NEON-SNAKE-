export type Position = {
  x: number;
  y: number;
};

export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export type GameState = 'START' | 'PLAYING' | 'PAUSED' | 'GAME_OVER';

export type GameMode = 'CLASSIC' | 'SPEED' | 'ENDLESS';

export const GRID_SIZE = 20;
export const CELL_SIZE = 20;
export const CANVAS_SIZE = GRID_SIZE * CELL_SIZE; // 400px
export const INITIAL_SPEED = 150; // ms per move
export const SPEED_INCREMENT = 10; // ms to decrease per level
export const POINTS_PER_LEVEL = 5;
