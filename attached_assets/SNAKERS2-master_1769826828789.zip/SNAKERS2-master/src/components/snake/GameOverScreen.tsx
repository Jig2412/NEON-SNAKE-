interface GameOverScreenProps {
  score: number;
  highScore: number;
  onRestart: () => void;
}

export function GameOverScreen({ score, highScore, onRestart }: GameOverScreenProps) {
  const isNewHighScore = score > 0 && score >= highScore;

  return (
    <div className="absolute inset-0 bg-[#0a0e14] bg-opacity-95 flex flex-col items-center justify-center z-10 noise-texture">
      <h2 className="font-display text-7xl md:text-8xl text-[#ff006e] mb-8 tracking-wider drop-shadow-[6px_6px_0_#000]">
        GAME OVER
      </h2>

      <div className="mb-12 text-center space-y-4">
        <div>
          <p className="font-body text-white text-lg mb-2">FINAL SCORE</p>
          <p className="font-mono-bold text-6xl text-[#39ff14]">{score}</p>
        </div>

        {isNewHighScore && (
          <div className="animate-pulse-scale">
            <p className="font-display text-3xl text-[#ccff00] drop-shadow-[3px_3px_0_#000]">
              NEW HIGH SCORE!
            </p>
          </div>
        )}

        <div>
          <p className="font-body text-gray-400 text-base mb-2">HIGH SCORE</p>
          <p className="font-mono-bold text-4xl text-white">{highScore}</p>
        </div>
      </div>

      <button
        onClick={onRestart}
        className="font-display text-2xl px-12 py-6 bg-[#ff6600] text-white border-[6px] border-black brutalist-shadow uppercase hover:translate-x-[3px] hover:translate-y-[3px] hover:shadow-[3px_3px_0_0_#000] transition-all active:translate-x-[6px] active:translate-y-[6px] active:shadow-none"
      >
        RESTART
      </button>
    </div>
  );
}
