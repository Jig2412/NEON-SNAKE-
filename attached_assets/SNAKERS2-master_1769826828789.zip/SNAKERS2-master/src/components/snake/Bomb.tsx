import { Position, CELL_SIZE } from './types';

interface BombProps {
  position: Position;
}

export function Bomb({ position }: BombProps) {
  return (
    <div
      className="absolute animate-pulse"
      style={{
        left: position.x * CELL_SIZE,
        top: position.y * CELL_SIZE,
        width: CELL_SIZE,
        height: CELL_SIZE,
      }}
    >
      <div className="w-full h-full bg-red-600 border-2 border-black relative">
        {/* Bomb fuse */}
        <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-0.5 h-1.5 bg-orange-500" />
        {/* Skull symbol */}
        <div className="absolute inset-0 flex items-center justify-center text-white text-xs font-bold">
          💣
        </div>
      </div>
    </div>
  );
}
