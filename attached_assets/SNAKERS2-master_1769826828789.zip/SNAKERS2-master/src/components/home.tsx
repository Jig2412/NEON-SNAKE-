import { SnakeGame } from "./snake/SnakeGame";

function Home() {
  return <SnakeGame />;
}

export default Home
