## Packages
framer-motion | Essential for smooth animations and game UI transitions

## Notes
Game loop will use requestAnimationFrame for smooth 60fps rendering on Canvas
Bomb mode logic will reside in the frontend game loop but scores are persisted
Google Fonts: 'Press Start 2P' for retro feel and 'Orbitron' for neon headers
